package err;

public enum ErrType {
    a, b, c, d, e, f, g, h, j, k, l, m
}
